import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'detail_eyeliner.dart';

class Eyeliner extends StatefulWidget {
  Eyeliner({Key key}) : super(key: key);

  @override
  _EyelinerState createState() => _EyelinerState();
}

class _EyelinerState extends State<Eyeliner> {
  Future<List<Top>> top;
  @override
  void initState() {
    super.initState();
    top = fetchTop();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/3.jpg'), fit: BoxFit.cover),
          ),
          child: SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(
                  height: 10,
                ),
                Text(
                  'Your Favorite Eyeliner',
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.white),
                ),
                SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.only(left: 20),
                  child: SizedBox(
                    // height: 200.0,
                    child: FutureBuilder<List<Top>>(
                        future: top,
                        builder: (context, snapshot) {
                          if (snapshot.hasData) {
                            return ListView.builder(
                              physics: ClampingScrollPhysics(),
                              shrinkWrap: true,
                              itemCount: snapshot.data.length,
                              itemBuilder: (BuildContext context, int index) =>
                                  Padding(
                                padding: const EdgeInsets.only(right: 20),
                                child: Card(
                                  color: Colors.black,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12.0),
                                  ),
                                  elevation: 0,
                                  shadowColor: Colors.black,
                                  child: ListTile(
                                    contentPadding: const EdgeInsets.symmetric(
                                        horizontal: 20.0, vertical: 10.0),
                                    // leading: Container(
                                    //   child: Image.network(
                                    //       snapshot.data[index].image),
                                    // ),
                                    title: Text(
                                      snapshot.data[index].name,
                                      style: TextStyle(
                                          color: Colors.white,
                                          letterSpacing: .5,
                                          fontSize: 15),
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 1,
                                    ),
                                    onTap: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) =>
                                              DetailEyelinerPage(
                                            item: snapshot.data[index].uuid,
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ),
                            );
                          }
                          return Center(
                            child: CircularProgressIndicator(),
                          );
                        }),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class Top {
  final int uuid;
  final String name;
  final String image;

  Top({
    this.uuid,
    this.name,
    this.image,
  });

  factory Top.fromJson(Map<String, dynamic> json) {
    return Top(
      uuid: json['id'],
      name: json['name'],
      image: json['image_link'],
    );
  }
}

// function untuk fetch api
Future<List<Top>> fetchTop() async {
  String api =
      'http://makeup-api.herokuapp.com/api/v1/products.json?product_type=eyeliner';
  final response = await http.get(
    Uri.parse(api),
  );

  if (response.statusCode == 200) {
    var topShowsJson = jsonDecode(response.body) as List,
        topShows = topShowsJson.map((top) => Top.fromJson(top)).toList();

    return topShows;
  } else {
    throw Exception('Failed to load shows');
  }
}

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

// ignore: must_be_immutable
class DetailEyelinerPage extends StatefulWidget {
  final String title;
  final int item;
  DetailEyelinerPage({
    Key key,
    this.title,
    this.item,
  }) : super(key: key);

  @override
  _DetailEyelinerPageState createState() => _DetailEyelinerPageState();
}

class _DetailEyelinerPageState extends State<DetailEyelinerPage> {
  Future<AiringDetail> detail;

  @override
  void initState() {
    super.initState();
    detail = fetchDetails(widget.item);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff1F1D2B),
      appBar: AppBar(
        centerTitle: true,
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Color(0xff1F1D2B),
        title: Text(
          'Details',
          style:
              TextStyle(color: Colors.white, letterSpacing: .5, fontSize: 15),
          overflow: TextOverflow.ellipsis,
        ),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Center(
            child: FutureBuilder<AiringDetail>(
          future: detail,
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              return Center(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 10,
                    ),
                    //gambar gede
                    Container(
                      height: 250,
                      width: MediaQuery.of(context).size.width,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.network(
                          snapshot.data.image,
                          errorBuilder: (BuildContext context, Object exception,
                              StackTrace stackTrace) {
                            return SizedBox();
                          },
                        ),
                      ),
                    ),
                    SizedBox(height: 10),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          SizedBox(
                            width: 5,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                snapshot.data.title,
                                style: TextStyle(
                                    color: Colors.white,
                                    letterSpacing: .5,
                                    fontSize: 15),
                                overflow: TextOverflow.fade,
                                maxLines: 2,
                              ),
                              SizedBox(height: 5),
                              Row(
                                children: [
                                  Text(
                                    snapshot.data.price,
                                    style: TextStyle(
                                        color: Colors.white,
                                        letterSpacing: .5,
                                        fontSize: 15),
                                    maxLines: 1,
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Text(
                                    '•',
                                    style: TextStyle(
                                        color: Colors.white, fontSize: 18),
                                  ),
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Text(
                                    snapshot.data.brand,
                                    style: TextStyle(
                                        color: Colors.white,
                                        letterSpacing: .5,
                                        fontSize: 15),
                                    maxLines: 1,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Text(
                        'Description',
                        style: TextStyle(
                            color: Colors.white,
                            letterSpacing: .5,
                            fontSize: 15),
                      ),
                    ),

                    Container(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 10),
                        child: Text(
                          snapshot.data.synopsis,
                          textAlign: TextAlign.justify,
                          style: TextStyle(
                              color: Colors.white,
                              letterSpacing: .5,
                              fontSize: 15),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            } else if (snapshot.hasError) {
              return const Center(child: Text('Gagal menampilkan data detail'));
            }
            return Center(child: const CircularProgressIndicator());
          },
        )),
      ),
    );
  }
}

class AiringDetail {
  String image;
  String title;
  String synopsis;
  int malId;
  String brand;
  // String sign;
  String price;

  AiringDetail({
    this.image,
    this.title,
    this.synopsis,
    this.malId,
    this.brand,
    // this.sign,
    this.price,
  });

  factory AiringDetail.fromJson(json) {
    return AiringDetail(
      image: json['image_link'],
      title: json['name'],
      synopsis: json['description'],
      malId: json['id'],
      brand: json['brand'],
      // sign: json['price_sign'],
      price: json['price'],
    );
  }
}

Future<AiringDetail> fetchDetails(int id) async {
  String api = 'http://makeup-api.herokuapp.com/api/v1/products/$id.json';
  var response = await http.get(
    Uri.parse(api),
  );

  if (response.statusCode == 200) {
    return AiringDetail.fromJson(jsonDecode(response.body));
  } else {
    throw Exception('Failed to load data');
  }
}

package com.example.skincare_pedia

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

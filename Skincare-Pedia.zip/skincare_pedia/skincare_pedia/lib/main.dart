import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:skincare_pedia/mainpage.dart';
import 'package:skincare_pedia/detail.dart';

class MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext context) {
    return super.createHttpClient(context)
      ..badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;
  }
}

void main() async {
  HttpOverrides.global = new MyHttpOverrides();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Skincare Pedia',
      home: MainPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomeScreen extends StatefulWidget {
  HomeScreen({Key key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Future<List<Eyebrow>> eyerbrows;
  @override
  void initState() {
    super.initState();
    eyerbrows = fetchEyebrow();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        child: Scaffold(
          body: Container(
            decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage('assets/2.jpg'), fit: BoxFit.cover)),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    'Your Favorite Eyebrow',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  Padding(
                    padding: const EdgeInsets.only(left: 20),
                    child: SizedBox(
                      // height: 200.0,
                      child: FutureBuilder<List<Eyebrow>>(
                          future: eyerbrows,
                          builder: (context, snapshot) {
                            if (snapshot.hasData) {
                              return ListView.builder(
                                physics: ClampingScrollPhysics(),
                                shrinkWrap: true,
                                itemCount: snapshot.data.length,
                                itemBuilder:
                                    (BuildContext context, int index) =>
                                        Padding(
                                  padding: const EdgeInsets.only(right: 20),
                                  child: Card(
                                    borderOnForeground: false,
                                    shadowColor: Colors.black,
                                    color: Color(0xffF5F5DC),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12.0),
                                    ),
                                    child: ListTile(
                                      contentPadding:
                                          const EdgeInsets.symmetric(
                                              horizontal: 20.0, vertical: 10.0),
                                      // leading: Container(
                                      //   child: Image.network(
                                      //       snapshot.data[index].image),
                                      // ),
                                      title: Text(
                                        snapshot.data[index].name,
                                        style: TextStyle(
                                            color: Colors.black,
                                            letterSpacing: .5,
                                            fontSize: 15),
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                      ),
                                      onTap: () {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) => DetailPage(
                                              // title: snapshot.data[index].title,
                                              item: snapshot.data[index].uuid,
                                            ),
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                ),
                              );
                            }
                            return Center(child: CircularProgressIndicator());
                          }),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class Eyebrow {
  final int uuid;
  final String name;
  final String image;
  // final String rating;

  Eyebrow({
    this.uuid,
    this.name,
    this.image,
    // this.rating,
  });

  factory Eyebrow.fromJson(Map<String, dynamic> json) {
    return Eyebrow(
      uuid: json['id'],
      name: json['name'],
      image: json['image_link'],
      // rating: json['rating'],
    );
  }
}

// function untuk fetch api
Future<List<Eyebrow>> fetchEyebrow() async {
  String api =
      'http://makeup-api.herokuapp.com/api/v1/products.json?product_type=eyebrow';
  final response = await http.get(
    Uri.parse(api),
  );

  if (response.statusCode == 200) {
    var eyebrowShowsJson = jsonDecode(response.body) as List,
        eyebrowShows =
            eyebrowShowsJson.map((top) => Eyebrow.fromJson(top)).toList();

    return eyebrowShows;
    //jika tidak di mapping hanya mendapat instance
    //intance of keynya
  } else {
    throw Exception('Failed to load shows');
  }
}
